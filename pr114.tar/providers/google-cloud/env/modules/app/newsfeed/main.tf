locals {
  vertex_location = "us-central1"
  schedule        = "0 */2 * * *"
  timezone        = "Asia/Tokyo"
}

# ──────────────────────────────────────────────
# API 有効化
# ──────────────────────────────────────────────

resource "google_project_service" "run" {
  project            = var.project_id
  service            = "run.googleapis.com"
  disable_on_destroy = false
}

resource "google_project_service" "cloudscheduler" {
  project            = var.project_id
  service            = "cloudscheduler.googleapis.com"
  disable_on_destroy = false
}

resource "google_project_service" "aiplatform" {
  project            = var.project_id
  service            = "aiplatform.googleapis.com"
  disable_on_destroy = false
}

# ──────────────────────────────────────────────
# GCS バケット (記事データ保存)
# ──────────────────────────────────────────────

resource "google_storage_bucket" "newsfeed" {
  name                        = var.bucket_name
  project                     = var.project_id
  location                    = var.region
  uniform_bucket_level_access = true
  force_destroy               = false

  lifecycle_rule {
    condition {
      age = 90
    }
    action {
      type = "Delete"
    }
  }
}

# ──────────────────────────────────────────────
# IAM (Cloud SQL は module.service_accounts で付与)
# ──────────────────────────────────────────────

resource "google_storage_bucket_iam_member" "newsfeed_gcs_writer" {
  bucket = google_storage_bucket.newsfeed.name
  role   = "roles/storage.objectCreator"
  member = "serviceAccount:${var.service_account_email}"
}

resource "google_storage_bucket_iam_member" "newsfeed_gcs_reader" {
  bucket = google_storage_bucket.newsfeed.name
  role   = "roles/storage.objectViewer"
  member = "serviceAccount:${var.service_account_email}"
}

resource "google_project_iam_member" "newsfeed_vertex_ai_user" {
  project = var.project_id
  role    = "roles/aiplatform.user"
  member  = "serviceAccount:${var.service_account_email}"
}

# ──────────────────────────────────────────────
# Cloud Run v2 ジョブ
# ──────────────────────────────────────────────

resource "google_cloud_run_v2_job" "newsfeed" {
  name                = "newsfeed-job"
  project             = var.project_id
  location            = var.region
  deletion_protection = false

  # CI/CD が gcloud でデプロイするたび image と client / client_version が書き換わるため drift を許容
  lifecycle {
    ignore_changes = [
      template[0].template[0].containers[0].image,
      client,
      client_version,
    ]
  }

  template {
    task_count = 1

    template {
      service_account = var.service_account_email
      max_retries     = 1
      timeout         = "1800s" # 30 min max

      containers {
        # 初回作成時のみ使う値。以降の実イメージは ignore_changes 対象で CI が所有する
        image = var.newsfeed_image

        env {
          name  = "APP_ENV"
          value = "production"
        }

        env {
          name  = "GOOGLE_CLOUD_PROJECT"
          value = var.project_id
        }

        env {
          name  = "VERTEX_LOCATION"
          value = local.vertex_location
        }
      }

      vpc_access {
        network_interfaces {
          network    = var.network
          subnetwork = var.subnetwork
        }
        egress = "PRIVATE_RANGES_ONLY"
      }
    }
  }
}

# ──────────────────────────────────────────────
# Cloud Scheduler (Newsfeed ジョブトリガー)
# ──────────────────────────────────────────────

resource "google_service_account" "newsfeed_scheduler" {
  project      = var.project_id
  account_id   = "newsfeed-scheduler"
  display_name = "Newsfeed Cloud Scheduler"
}

resource "google_cloud_run_v2_job_iam_member" "scheduler_invoker" {
  project  = var.project_id
  location = var.region
  name     = google_cloud_run_v2_job.newsfeed.name
  role     = "roles/run.invoker"
  member   = "serviceAccount:${google_service_account.newsfeed_scheduler.email}"
}

resource "google_cloud_scheduler_job" "newsfeed" {
  name        = "newsfeed-fetch"
  project     = var.project_id
  region      = var.region
  description = "Trigger newsfeed Cloud Run Job every 2 hours"
  schedule    = local.schedule
  time_zone   = local.timezone
  paused      = var.scheduler_paused

  http_target {
    http_method = "POST"
    uri         = "https://${var.region}-run.googleapis.com/apis/run.googleapis.com/v1/namespaces/${var.project_id}/jobs/${google_cloud_run_v2_job.newsfeed.name}:run"

    oauth_token {
      service_account_email = google_service_account.newsfeed_scheduler.email
      scope                 = "https://www.googleapis.com/auth/cloud-platform"
    }
  }
}

# ──────────────────────────────────────────────
# デプロイ SA にジョブ実行権限を付与 (CI/CD)
# ──────────────────────────────────────────────

resource "google_cloud_run_v2_job_iam_member" "deploy_invoker" {
  project  = var.project_id
  location = var.region
  name     = google_cloud_run_v2_job.newsfeed.name
  role     = "roles/run.invoker"
  member   = var.deploy_sa_member
}

